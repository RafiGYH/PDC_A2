/* Auckland University of Technology (AUT), COMP603 Program Design and Construction
 * 
 * Project 2 - Cinema Booking System
 * Menu.Java - Responsible for displaying messages and gathering input from the user
 * 
 * @Authors Group #60 | Thomas Brears #20122554 & Rafi Yusaf-Horsfall 20119318
 * @Created August 2023
 * @Modified October 2023
*/
package pdcassignment2;

import java.util.*;

public class Menu {
    //Sidenote: I chose to make this class into methods and not hard code into main due to reuseability
    public Scanner scan;
   
    String fullName;
    String phoneNumber;
    String email;
    
    public Menu(){
        scan = new Scanner(System.in);//Side note: Will allow any instantiation to use this when taking a method
    }
    
    public int displayMainMenu(BookingSystemGUI gui)
    {
        String selectedOption = (String) gui.mainMenuOptions.getSelectedItem();
        if("Look up an existing booking".equals(selectedOption)){
            return 1;
        }else if ("Make a new booking".equals(selectedOption)) {
            return 2;
        } else if ("Quit the program".equals(selectedOption)) {
            return 3;
        } else {
            return 0;
        }
    }
    
    //Movie Choices
    public String displayMovieChoices(BookingSystemGUI gui) {
        return (String) gui.movieChoices.getSelectedItem();
    }

    //Date and Time Choices
    public String displayDateTimeChoices(BookingSystemGUI gui) {
        return (String) gui.dateTimeChoices.getSelectedItem();
    }

    //Ticket Count Choices
    public String displayTicketCountChoices(BookingSystemGUI gui) {
        return (String) gui.ticketCountChoices.getSelectedItem();
    }

    //Name Input
    public String getNameInput(BookingSystemGUI gui) {
        return gui.nameInput.getText();
    }

    //Phone Input
    public String getPhoneInput(BookingSystemGUI gui) {
        return gui.phoneInput.getText();
    }

    //Email Input
    public String getEmailInput(BookingSystemGUI gui) {
        return gui.emailInput.getText();
    }
    
    public String displayTicketTypeChoices(BookingSystemGUI gui) {
        return (String) gui.ticketTypeChoices.getSelectedItem();
    }
    
    
   
}