/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdcassignment2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author rafis
 */
public class BookingSystemGUI {
    
    private JFrame frame;
    public JComboBox<String> mainMenuOptions;
    public JComboBox<String> movieChoices;
    public JComboBox<String> dateTimeChoices;
    public JComboBox<String> ticketCountChoices;
    public JComboBox<String> ticketTypeChoices;
    public JTextField ticketType;
    public JTextField nameInput;
    public JTextField phoneInput;
    public JTextField emailInput;
    public JButton nextButton;
    public JButton quitButton;
    public JTextField phoneNumberLookupField;
    public JButton searchButton;
    public JButton confirmButton;
    public JButton backButton;
    public JButton restartButton;
    
    //Promo code addition
    public JLabel promoCodeLabel;
    public JTextField promoCodeInput;

    public BookingSystemGUI() {
        frame = new JFrame("Cinema Booking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        // Main Menu Dropdown
        String[] options = {"Look up an existing booking", "Make a new booking"};
        mainMenuOptions = new JComboBox<>(options);
        c.gridx = 0;
        c.gridy = 0;
        panel.add(mainMenuOptions, c);

        // Movie Choices Dropdown
        
        String[] movies = {"Select a movie", "Movie A", "Movie B", "Movie C"};
        movieChoices = new JComboBox<>(movies);
        c.gridy = 1;
        panel.add(movieChoices, c);

        // Date and Time Dropdown
        
        String[] dateTimes = {"Select date and time", "Date1 Time1", "Date2 Time2", "Date3 Time3"};
        dateTimeChoices = new JComboBox<>(dateTimes);
        c.gridy = 2;
        panel.add(dateTimeChoices, c);

        // Ticket Count Dropdown
        String[] ticket = {"Select number of tickets", "1", "2", "3", "4"};
        ticketCountChoices = new JComboBox<>(ticket);
        c.gridy = 3;
        panel.add(ticketCountChoices, c);
        
        // Ticket Type dropdown
        String[] ticketTypes = {"Select type of tickets", "Normal", "Premuim"};
        ticketTypeChoices = new JComboBox<>(ticketTypes);
        c.gridy = 4;
        panel.add(ticketTypeChoices, c);
        

        // Name Input
        nameInput = new JTextField("Enter your name");
        c.gridy = 5;
        panel.add(nameInput, c);

        // Phone Input
        phoneInput = new JTextField("Enter your phone number");
        c.gridy = 6;
        panel.add(phoneInput, c);

        // Email Input
        emailInput = new JTextField("Enter your email");
        c.gridy = 7;
        panel.add(emailInput, c);

        // Next Button
        nextButton = new JButton("Next");
        c.gridy = 8;
        panel.add(nextButton, c);

        // Quit Button
        quitButton = new JButton("Quit");
        c.gridy = 9;
        panel.add(quitButton, c);

        
        
        mainMenuOptions.setVisible(true);
        movieChoices.setVisible(false);
        dateTimeChoices.setVisible(false);
        ticketCountChoices.setVisible(false);
        nameInput.setVisible(false);
        phoneInput.setVisible(false);
        emailInput.setVisible(false);
        ticketTypeChoices.setVisible(false);
        phoneNumberLookupField = new JTextField("Enter phone number to lookup", 20);  
        searchButton = new JButton("Search");
        confirmButton = new JButton("Confirm");
        backButton = new JButton("Back");
        
        
        promoCodeLabel = new JLabel("Do you have a promo code?");
        promoCodeInput = new JTextField("Enter promo code here");
        c.gridy = 5;  
        panel.add(promoCodeLabel, c);

        c.gridy = 6;  
        panel.add(promoCodeInput, c);
        
        backButton.setVisible(false);
        c.gridy = 11;
        panel.add(backButton, c);
        
        c.gridy = 10; 
        panel.add(confirmButton, c);
        confirmButton.setVisible(false);
        
        restartButton = new JButton("Restart");
        c.gridy = 12;  
        panel.add(restartButton, c);
        restartButton.setVisible(true);
        
        
        promoCodeLabel.setVisible(false);
        promoCodeInput.setVisible(false);
        
        // Action Listeners
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            String selectedOption = (String) mainMenuOptions.getSelectedItem();
            if ("Look up an existing booking".equals(selectedOption)) {
            
            panel.removeAll();
            c.gridy = 0;
            panel.add(phoneNumberLookupField, c);
            
            // Add Search buttoon
            c.gridy = 1;
            panel.add(searchButton, c);

            // Repaint and rev.
            panel.repaint();
            panel.revalidate();
        }
                
                handleNextButton();
            }
        });

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        
        //Should function as the AL for the searchbutton
searchButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String phoneNumber = phoneNumberLookupField.getText();

        // Connect to the database
        try {
            Connection conn = DatabaseUtility.connect();

            // SQL for dind
            String query = "SELECT * FROM Bookings WHERE PhoneNumber = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, phoneNumber);
            ResultSet rs = pstmt.executeQuery();

            // Check if a booking is found
            if (rs.next()) {
                //This will display our booking ingo 
                String fullName = rs.getString("FullName");
                String email = rs.getString("Email");
                // Add more fields as needed
                JOptionPane.showMessageDialog(frame, "Booking found:\nName: " + fullName + "\nEmail: " + email);
            } else {
                //Error message
                JOptionPane.showMessageDialog(frame, "No booking found for the provided phone number.");
            }

        } catch (DatabaseException | SQLException ex) {
            JOptionPane.showMessageDialog(frame, "An error occurred while accessing the database.");
        }
    }
    
    
    
    
});




backButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        handleBackButton(); 
    }
});




mainMenuOptions.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String selectedOption = (String) mainMenuOptions.getSelectedItem();
        if ("Quit the program".equals(selectedOption)) {
            System.exit(0);
        }
    }
});

confirmButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int test =1;
        String selectedMovie = (String) movieChoices.getSelectedItem();
        System.out.println(test++);
        String selectedDateTime = (String) dateTimeChoices.getSelectedItem();
        System.out.println(test++);
        String selectedTicketCount = (String) ticketCountChoices.getSelectedItem();
        System.out.println(test++);
        String selectedTicketType = (String) ticketTypeChoices.getSelectedItem();
        System.out.println(test++);
        String enteredName = nameInput.getText();
        System.out.println(test++);
        String enteredPhone = phoneInput.getText();
        System.out.println(test++);
        String enteredEmail = emailInput.getText();
        System.out.println(test++);
        String promoCode = promoCodeInput.getText();
        System.out.println(promoCode+"test");

        Booking newBooking = new Booking();
        System.out.println(1+1);
        newBooking.setFullName(enteredName);
        System.out.println(1+1);
        newBooking.setPhoneNumber(enteredPhone);
        System.out.println(1+1);
        newBooking.setEmail(enteredEmail);
        System.out.println(1+1);
        newBooking.setShowTime(selectedDateTime);
        System.out.println(1+1);
        newBooking.setMovieTitle(selectedMovie);
        System.out.println(1+1);
        newBooking.setTicketType(selectedTicketType);
        System.out.println(1+1);
        newBooking.setTicketQuantity(Integer.parseInt(selectedTicketCount));
        System.out.println(1+1);

        BookingSystem.insertNewBooking(newBooking);
        System.out.println("added");

        JOptionPane.showMessageDialog(frame, "Booking successfully created!");
    }
});

        
    restartButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        resetToInitialState();
    }
});    
        
        frame.add(panel);
 
    }
     
    public String getSelectedMainMenuOption() {
        return (String) mainMenuOptions.getSelectedItem();
    }
    
   private void handleNextButton() {
    if (mainMenuOptions.isVisible()) {
        String selectedOption = (String) mainMenuOptions.getSelectedItem();
        mainMenuOptions.setVisible(false);

        if ("Look up an existing booking".equals(selectedOption)) {
            phoneInput.setVisible(true);
        } else if ("Make a new booking".equals(selectedOption)) {
            movieChoices.setVisible(true);
            
        }
        return;
    }
 
    if (movieChoices.isVisible()) {
        
        movieChoices.setVisible(false);
        dateTimeChoices.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (dateTimeChoices.isVisible()) {
        dateTimeChoices.setVisible(false);
        ticketCountChoices.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (ticketCountChoices.isVisible()) {
        ticketCountChoices.setVisible(false);
        ticketTypeChoices.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (ticketTypeChoices.isVisible()) {
        ticketTypeChoices.setVisible(false);
        nameInput.setVisible(true);
        return;
    }

    if (nameInput.isVisible()) {
        System.out.println("Handling nameInput");
        nameInput.setVisible(false);
        phoneInput.setVisible(true);
        backButton.setVisible(true);
        frame.revalidate();
        frame.repaint();
        return;
    }

    if (phoneInput.isVisible()) {
        System.out.println("Handling phoneInput");
        phoneInput.setVisible(false);
        emailInput.setVisible(true);
        backButton.setVisible(true);
        frame.revalidate();
        frame.repaint();
        return;
    }

    if (emailInput.isVisible()) {
    emailInput.setVisible(false);
    promoCodeLabel.setVisible(true);
    promoCodeInput.setVisible(true);
    backButton.setVisible(true);
    frame.revalidate();
    frame.repaint();
    return;
}

    if (emailInput.isVisible()) {
        emailInput.setVisible(false);
        promoCodeLabel.setVisible(true);
        promoCodeInput.setVisible(true);
        backButton.setVisible(true);
        frame.revalidate();
        frame.repaint();
        return;
    }

    if (promoCodeLabel.isVisible() && promoCodeInput.isVisible()) {
        promoCodeLabel.setVisible(false);
        promoCodeInput.setVisible(false);
        confirmButton.setVisible(true);
        nextButton.setVisible(false);  
        backButton.setVisible(false);
        frame.revalidate();
        frame.repaint();
        return;
    }
    
        
    }
    
    
    
    public void display() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        
    }
    
    
private void handleBackButton() {
    
    if (confirmButton.isVisible()) {
        emailInput.setVisible(true);
        confirmButton.setVisible(false);
        //nextButton.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (emailInput.isVisible()) {
        emailInput.setVisible(false);
        phoneInput.setVisible(true);
        return;
    }

    if (phoneInput.isVisible()) {
        phoneInput.setVisible(false);
        nameInput.setVisible(true);
        return;
    }

    if (nameInput.isVisible()) {
        nameInput.setVisible(false);
        ticketTypeChoices.setVisible(true);
        return;
    }

    if (ticketTypeChoices.isVisible()) {
        ticketTypeChoices.setVisible(false);
        ticketCountChoices.setVisible(true);
        return;
    }

    if (ticketCountChoices.isVisible()) {
        ticketCountChoices.setVisible(false);
        dateTimeChoices.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (dateTimeChoices.isVisible()) {
        dateTimeChoices.setVisible(false);
        movieChoices.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (movieChoices.isVisible()) {
        movieChoices.setVisible(false);
        //backButton.setVisible(true);
        mainMenuOptions.setVisible(true);
        return;
    }
    
     if (confirmButton.isVisible()) {
        confirmButton.setVisible(false);
        promoCodeLabel.setVisible(true);
        promoCodeInput.setVisible(true);
        backButton.setVisible(true);
        return;
    }

    if (promoCodeLabel.isVisible() && promoCodeInput.isVisible()) {
        promoCodeLabel.setVisible(false);
        promoCodeInput.setVisible(false);
        emailInput.setVisible(true);
        backButton.setVisible(true);
        return;
    }
    
}

    private void resetToInitialState() {//Resseter should function via  reset 
    mainMenuOptions.setVisible(true);
    mainMenuOptions.setSelectedIndex(0); 
    
    movieChoices.setVisible(false);
    movieChoices.setSelectedIndex(0);
    
    dateTimeChoices.setVisible(false);
    dateTimeChoices.setSelectedIndex(0);
    
    ticketCountChoices.setVisible(false);
    ticketCountChoices.setSelectedIndex(0);
    
    ticketTypeChoices.setVisible(false);
    ticketTypeChoices.setSelectedIndex(0);
    
    nameInput.setVisible(false);
    nameInput.setText("Enter your name");
    
    phoneInput.setVisible(false);
    phoneInput.setText("Enter your phone number");
    
    emailInput.setVisible(false);
    emailInput.setText("Enter your email");
    
    nextButton.setVisible(true);
    confirmButton.setVisible(false);
    backButton.setVisible(false);
    
    promoCodeLabel.setVisible(false);
    promoCodeInput.setVisible(false);
    
}
    
}